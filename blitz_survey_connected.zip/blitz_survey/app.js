// 1. Создайте проект на https://supabase.com
// 2. Вставьте Project URL и anon/public key из Project Settings → API.
const SUPABASE_URL = "https://onkaivysbkdnoteuydva.supabase.co";
const SUPABASE_ANON_KEY = "sb_publishable_Gd-y-1X-JVVbEm6YlZh-4g_d4Xyefaw";
const configured = SUPABASE_URL.startsWith("https://") && !SUPABASE_ANON_KEY.includes("ВСТАВЬТЕ");
const db = configured && window.supabase ? window.supabase.createClient(SUPABASE_URL, SUPABASE_ANON_KEY) : null;
const questions = window.SURVEY_QUESTIONS;
let current = 0; const answers = Array(questions.length).fill(null);
const $ = id => document.getElementById(id);
function show(id){["intro","survey","done"].forEach(x=>$(x).classList.toggle("hidden",x!==id));}
function render(){
 const q=questions[current]; $("sectionLabel").textContent=q.section.toUpperCase();
 $("questionCounter").textContent=`Вопрос ${current+1} из ${questions.length}`;
 $("progressPercent").textContent=`${Math.round((current+1)/questions.length*100)}%`;
 $("progressBar").style.width=`${(current+1)/questions.length*100}%`;
 $("questionText").textContent=q.text; $("options").innerHTML="";
 q.options.forEach((o,i)=>{const label=document.createElement("label");label.className="option"+(answers[current]===i?" selected":"");
 label.innerHTML=`<span class="option-letter">${"ABCD"[i]}</span><span class="option-text"></span><span class="radio-dot"></span>`;
 label.querySelector(".option-text").textContent=o;label.addEventListener("click",()=>{answers[current]=i;render();});$("options").appendChild(label);});
 $("backBtn").disabled=current===0;$("nextBtn").disabled=answers[current]===null;
 $("nextBtn").textContent=current===questions.length-1?"Отправить ответы ✓":"Далее →";
}
$("startBtn").addEventListener("click",()=>{if(!db){$("configWarning").classList.remove("hidden");return;}current=0;show("survey");render();});
$("backBtn").addEventListener("click",()=>{if(current>0){current--;render();}});
$("nextBtn").addEventListener("click",async()=>{
 if(answers[current]===null)return;
 if(current<questions.length-1){current++;render();return;}
 $("nextBtn").disabled=true;$("nextBtn").textContent="Отправка…";
 try{
  const payload=answers.map((choice,i)=>({question_number:i+1,selected_option:choice+1}));
  const {error}=await db.rpc("submit_survey", {p_answers:payload});
  if(error)throw error;
  show("done");
 }catch(err){alert("Не удалось отправить ответы. Проверьте подключение и настройки базы данных. Подробности: "+err.message);$("nextBtn").disabled=false;$("nextBtn").textContent="Повторить отправку";}
});
$("againBtn").addEventListener("click",()=>{answers.fill(null);current=0;show("intro");$("configWarning").classList.add("hidden");});
