-- Выполните этот SQL в Supabase → SQL Editor.
create table if not exists public.survey_responses (
  id uuid primary key default gen_random_uuid(),
  created_at timestamptz not null default now()
);
create table if not exists public.survey_answers (
  id bigint generated always as identity primary key,
  response_id uuid not null references public.survey_responses(id) on delete cascade,
  question_number int not null check (question_number between 1 and 22),
  selected_option int not null check (selected_option between 1 and 4),
  created_at timestamptz not null default now(),
  unique(response_id, question_number)
);
create table if not exists public.survey_admins (
  user_id uuid primary key references auth.users(id) on delete cascade
);
alter table public.survey_responses enable row level security;
alter table public.survey_answers enable row level security;
alter table public.survey_admins enable row level security;
create or replace function public.is_survey_admin()
returns boolean language sql security definer stable
set search_path = public
as $$ select exists(select 1 from public.survey_admins where user_id = auth.uid()); $$;
revoke all on function public.is_survey_admin() from public;
grant execute on function public.is_survey_admin() to authenticated, anon;
-- Public can submit anonymous responses. Public cannot read responses or answers.
create policy "Anyone can submit a response" on public.survey_responses
for insert to anon, authenticated with check (true);
create policy "Anyone can submit answers" on public.survey_answers
for insert to anon, authenticated with check (true);
create policy "Admins can read responses" on public.survey_responses
for select to authenticated using (public.is_survey_admin());
create policy "Admins can read answers" on public.survey_answers
for select to authenticated using (public.is_survey_admin());
create policy "Admins can read admin list" on public.survey_admins
for select to authenticated using (user_id = auth.uid());
grant usage on schema public to anon, authenticated;
grant insert on public.survey_responses to anon, authenticated;
grant insert on public.survey_answers to anon, authenticated;
grant select on public.survey_responses, public.survey_answers to authenticated;
grant select on public.survey_admins to authenticated;
grant usage, select on sequence public.survey_answers_id_seq to anon, authenticated;


-- Атомарная отправка всей анкеты: либо сохраняются все ответы, либо ни один.
create or replace function public.submit_survey(p_answers jsonb)
returns uuid
language plpgsql
security definer
set search_path = public
as $$
declare
  new_response_id uuid;
  item jsonb;
  q_num int;
  opt_num int;
  seen int[] := '{}';
begin
  if jsonb_typeof(p_answers) <> 'array' or jsonb_array_length(p_answers) <> 22 then
    raise exception 'Опрос должен содержать ровно 22 ответа';
  end if;
  insert into public.survey_responses default values returning id into new_response_id;
  for item in select * from jsonb_array_elements(p_answers)
  loop
    q_num := (item->>'question_number')::int;
    opt_num := (item->>'selected_option')::int;
    if q_num < 1 or q_num > 22 or opt_num < 1 or opt_num > 4 or q_num = any(seen) then
      raise exception 'Некорректный ответ';
    end if;
    seen := array_append(seen,q_num);
    insert into public.survey_answers(response_id,question_number,selected_option)
    values(new_response_id,q_num,opt_num);
  end loop;
  if cardinality(seen) <> 22 then raise exception 'Не все вопросы отвечены'; end if;
  return new_response_id;
end;
$$;
revoke all on function public.submit_survey(jsonb) from public;
grant execute on function public.submit_survey(jsonb) to anon, authenticated;
