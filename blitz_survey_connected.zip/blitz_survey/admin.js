const SUPABASE_URL = "https://onkaivysbkdnoteuydva.supabase.co";
const SUPABASE_ANON_KEY = "sb_publishable_Gd-y-1X-JVVbEm6YlZh-4g_d4Xyefaw";
const configured = SUPABASE_URL.startsWith("https://") && !SUPABASE_ANON_KEY.includes("ВСТАВЬТЕ");
const db = configured && window.supabase ? window.supabase.createClient(SUPABASE_URL,SUPABASE_ANON_KEY) : null;
const $=id=>document.getElementById(id);let cachedResponses=[],cachedAnswers=[];
function message(t){$("loginMessage").textContent=t;}
$("loginForm").addEventListener("submit",async e=>{e.preventDefault();if(!db){message("Сначала настройте Supabase в admin.js.");return;}
 const {error}=await db.auth.signInWithPassword({email:$("email").value,password:$("password").value});
 if(error){message("Ошибка входа: "+error.message);return;}await loadDashboard();});
async function loadDashboard(){
 const {data:{user}}=await db.auth.getUser();if(!user)return;
 const {data:responses,error:e1}=await db.from("survey_responses").select("id,created_at").order("created_at",{ascending:false});
 if(e1){message("Нет доступа к результатам: "+e1.message);return;}
 const {data:answers,error:e2}=await db.from("survey_answers").select("response_id,question_number,selected_option");
 if(e2){message("Ошибка загрузки ответов: "+e2.message);return;}
 cachedResponses=responses||[];cachedAnswers=answers||[];
 $("loginPanel").classList.add("hidden");$("dashboard").classList.remove("hidden");
 $("totalResponses").textContent=cachedResponses.length;$("totalAnswers").textContent=cachedAnswers.length;
 $("lastResponse").textContent=cachedResponses[0]?new Date(cachedResponses[0].created_at).toLocaleDateString("ru-RU"):"—";
 renderResults();
}
function renderResults(){
 const root=$("results");root.innerHTML="";
 window.SURVEY_QUESTIONS.forEach((q,index)=>{
  const counts=[0,0,0,0];cachedAnswers.filter(a=>a.question_number===index+1).forEach(a=>{if(a.selected_option>=1&&a.selected_option<=4)counts[a.selected_option-1]++;});
  const total=counts.reduce((a,b)=>a+b,0);const card=document.createElement("article");card.className="result-card";
  const title=document.createElement("h3");title.textContent=`${index+1}. ${q.text}`;card.appendChild(title);
  const meta=document.createElement("p");meta.className="result-meta";meta.textContent=`${q.section} · ${total} ответов`;card.appendChild(meta);
  q.options.forEach((opt,i)=>{const pct=total?counts[i]/total*100:0;const row=document.createElement("div");row.className="result-row";
   const top=document.createElement("div");top.className="result-top";const name=document.createElement("span");name.textContent=opt;const val=document.createElement("strong");val.textContent=`${counts[i]} · ${pct.toFixed(1)}%`;top.append(name,val);
   const track=document.createElement("div");track.className="result-track";const fill=document.createElement("div");fill.className="result-fill";fill.style.width=pct+"%";track.appendChild(fill);row.append(top,track);card.appendChild(row);});
  root.appendChild(card);
 });
}
$("refreshBtn").addEventListener("click",loadDashboard);
$("logoutBtn").addEventListener("click",async()=>{await db.auth.signOut();$("dashboard").classList.add("hidden");$("loginPanel").classList.remove("hidden");});
$("exportBtn").addEventListener("click",()=>{
 const rows=[["Участник ID","Дата","Номер вопроса","Вариант ответа","Текст ответа"]];
 cachedResponses.forEach(r=>cachedAnswers.filter(a=>a.response_id===r.id).forEach(a=>{const q=window.SURVEY_QUESTIONS[a.question_number-1];rows.push([r.id,r.created_at,a.question_number,a.selected_option,q?.options[a.selected_option-1]||""]);}));
 const csv="\uFEFF"+rows.map(row=>row.map(v=>'"'+String(v??"").replaceAll('"','""')+'"').join(";")).join("\n");
 const blob=new Blob([csv],{type:"text/csv;charset=utf-8;"});const url=URL.createObjectURL(blob);const a=document.createElement("a");a.href=url;a.download="blitz-survey-results.csv";a.click();URL.revokeObjectURL(url);
});
(async()=>{if(!db){message("Добавьте URL и anon key Supabase в admin.js.");return;}const {data:{session}}=await db.auth.getSession();if(session)await loadDashboard();})();
